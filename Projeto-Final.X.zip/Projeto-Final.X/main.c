/*
    Fernanda Pereira de Sene - 2020026330
    DeLorean - Simulador do de volta para o futuro
*/

#include <pic18f4520.h>
#include "ssd.h"
#include "config.h"
#include "bits.h"
#include "lcd.h"
#include "keypad.h"
#include "atraso.h"
#include "pwm.h"

long int unsigned contador = 0;
static const char segmentos[]={ 0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F };

int controle = 0;

void shift(int tempo, int opcao){    
    int i;
    
    switch(opcao){
        case 0: 
            for(i = 0; i < 9; i++){
                atraso_ms(tempo);
                lcd_cmd(0x18); //lcd desliza pra esquerda
            }

            for(i = 0; i < 9; i++){
                atraso_ms(tempo);
                lcd_cmd(0x1C); //lcd desliza pra direita
            }
            atraso_ms(1000);
            break;
        case 1:
            for(i = 0; i < 12; i++){
                atraso_ms(tempo);
                lcd_cmd(0x1C); //lcd desliza pra direita
            }
            atraso_ms(1000);
            break;
        default:
        break;
    }
}

void abertura(){   
    lcd_cmd(L_L1);
    lcd_str(" BACK TO <--");
    
    lcd_cmd(L_L2);
    lcd_str(" THE FUTURE -->");
    
    shift(200, 0);
    
    lcd_cmd(L_L4);
    lcd_str(" Iniciando...");
    atraso_ms(1500);
}

void introducao(){
    lcd_cmd(L_L2);
    lcd_str("[PRESENTE TEMPO]");
    lcd_cmd(L_L3);
    lcd_str("[AGO] 01 2021 04");
    
    atraso_ms(3000);
    controle = 0;
    lcd_cmd(L_CLR);
}

void buzzer(int duracao){
    pwmFrequency(10000); // buzzer
                
    for(char k=0; k<3; k++){
        for(char j=1; j>0; j=j*2){
            bitSet(TRISC, 1);
            PORTB = j;
            PORTD = j;
            atraso_ms(duracao);
        }
        bitClr(TRISC, 1);
    }
    PORTB = 0;
    PORTD = 0;

}

void tempo(int inicio, int fim){
    int i;
    
    PORTD = 0x00;
    contador = inicio*60; // segundos
    
    while(1){ // contagem em segundos e milissegundos
        for(i=2; i<6; i++){
            if(i == 2) PORTD = segmentos[(contador/60)/10]; 
            if(i == 3) PORTD = segmentos[(contador/60)%10];
            if(i == 4) PORTD = segmentos[(contador%60)/10];
            if(i == 5) PORTD = segmentos[(contador%60)%10];
            PORTA = 0x00;
            bitSet(PORTA,i); //liga um display de cada vez
            atraso_ms(1);
            
            for(float flicker = 0; flicker < 50; flicker++);
        }
        
        contador--;
        
        if(contador == fim*60){ // termina em segundos
            PORTA = 0x00;
            break;
        }
    }
}

void imprime_carro(){
    int i;
    
    char delorean[64] = {
        0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x0C, // 1-sup
        0x00, 0x00, 0x00, 0x0F, 0x10, 0x00, 0x00, 0x00, // 2-sup
        0x00, 0x00, 0x00, 0x1C, 0x02, 0x01, 0x00, 0x00, // 3-sup
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x06, // 4-sup
        0x0C, 0x0C, 0x06, 0x01, 0x00, 0x00, 0x00, 0x00, // 5-inf
        0x08, 0x08, 0x14, 0x03, 0x14, 0x08, 0x00, 0x00, // 6-inf
        0x00, 0x01, 0x02, 0x1C, 0x02, 0x01, 0x00, 0x00, // 7-inf
        0x01, 0x01, 0x11, 0x0E, 0x10, 0x00, 0x00, 0x00, // 8-inf
    };
    
    lcd_cmd(0x40);
    for(i=0; i<64; i++){
        lcdData(delorean[i]);
    }
    
    lcd_cmd(L_L1);
    lcdData(0);
    lcdData(1);
    lcdData(2);
    lcdData(3);
    
    lcd_cmd(L_L2);
    lcdData(4);
    lcdData(5);
    lcdData(6);
    lcdData(7);
       
    shift(100, 1);
    
    lcd_cmd(L_CLR);
    
    lcd_cmd(L_L3);
    lcdData(0);
    lcdData(1);
    lcdData(2);
    lcdData(3);
    
    lcd_cmd(L_L4);
    lcdData(4);
    lcdData(5);
    lcdData(6);
    lcdData(7);
    
    shift(100, 1);
}

void escolherData(){
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("[DESTINOS TEMPO]");
    lcd_cmd(L_L2);
    lcd_str("[OCT] 26 1885 09");      
    lcd_cmd(L_L3);    
    lcd_str("[OCT] 21 2015 04");
    lcd_cmd(L_L4);
    lcd_str("[AGO] 01 2021 06");      
}

void ano_escolhido(unsigned int tecla){    
    switch(tecla){
        case 1:    
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[  -> RAIO <-  ]");
            tempo(10,0);
            buzzer(50);
            pwmSet(96);
            pwmFrequency(1000);
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str(" Mes Dia Ano Hor");
            lcd_cmd(L_L3);
            lcd_str("[OUT] 26 1885 09");
            
            atraso_ms(2000);
            
            lcd_cmd(L_CLR);
            imprime_carro();
            atraso_ms(1000);
            //carroEscolhido();
            
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[Tempo Esgotado]");
            lcd_cmd(L_L3);
            lcd_str("[    RETORNO   ]");
            atraso_ms(3000);
            lcd_cmd(L_CLR);
            
            pwmSet(0);
            pwmFrequency(0);
            controle = 2;
            break;
        case 2:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[  -> RAIO <-  ]");
            tempo(10,0);
            pwmSet(96);
            pwmFrequency(1000);
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str(" Mes Dia Ano Hor");
            lcd_cmd(L_L3);
            lcd_str("[NOV] 05 1955 09");
            
            atraso_ms(2000);
            
            lcd_cmd(L_CLR);
            imprime_carro();
            atraso_ms(1000);
            //carroEscolhido();
            
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[Tempo Esgotado]");
            lcd_cmd(L_L3);
            lcd_str("[    RETORNO   ]");
            atraso_ms(3000);
            lcd_cmd(L_CLR);
            
            pwmSet(0);
            pwmFrequency(0);
            controle = 2;
        case 3:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[  -> RAIO <-  ]");
            tempo(10,0);
            pwmSet(96);
            pwmFrequency(1000);
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str(" Mes Dia Ano Hor");
            lcd_cmd(L_L3);
            lcd_str("[OUT] 21 2015 09");
            
            atraso_ms(2000);
            
            lcd_cmd(L_CLR);
            imprime_carro();
            atraso_ms(1000);
            //carroEscolhido();
            
            lcd_cmd(L_CLR);
            lcd_cmd(L_L2);
            lcd_str("[Tempo Esgotado]");
            lcd_cmd(L_L3);
            lcd_str("[    RETORNO   ]");
            atraso_ms(3000);
            lcd_cmd(L_CLR);
            
            pwmSet(0);
            pwmFrequency(0);
            controle = 2;
        break;
    }
}

unsigned int leituraTecla(){
    unsigned int tecla;

    kpInit();
    kpDebounce();
    
    if(kpRead() != tecla){
        tecla = kpRead();

        if(bitTst(tecla, 3)){ // tecla 1
            return 1;
        }
        if(bitTst(tecla, 7)){ // tecla 2
            return 2;
        }
        if(bitTst(tecla, 11)){ // tecla 3
            return 3;
        }
        if(bitTst(tecla, 2)){ // tecla 4
            return 4;
        }
        if(bitTst(tecla, 6)){ // tecla 5
            return 5;
        }

        for(int tempo=0; tempo<1000; tempo++);  // temporizacao para evitar resquicios nos leds
    }
}

void main(void){
    lcdInit();
    ssdInit();
    pwmInit();
    
    abertura();
    lcd_cmd(L_CLR);
    introducao();
    lcd_cmd(L_CLR);
    
    for(;;){    
        if(controle == 0){
            escolherData();
            while(!leituraTecla()){
                controle = 0;
            }       
            controle = 1;
        }else if(controle == 1){
            ano_escolhido(leituraTecla());
        }

        if(controle == 2) goto sair;
    }   
    sair:
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("[PRESENTE TEMPO]");
    lcd_cmd(L_L2);
    lcd_str("[AGO] 01 2021 04");
    lcd_cmd(L_L4);
    lcd_str("[Carga 0 - fluxo]");
    atraso_ms(5000);
    lcd_cmd(L_CLR);
    
    while(1);
}

