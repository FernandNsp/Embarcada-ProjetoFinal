#ifndef ATRASO_H
    #define ATRASO_H
   
    void atraso_ms(unsigned int t);
    
#endif